CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image VARCHAR(255) NOT NULL,
    title VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL
);

INSERT INTO products (image, title, price) VALUES
('images/shopping%20(2).webp', 'Heak Jones', 30.00),
('images/images.jpg', 'Sum Joggers', 60.00),
('images/tyu.webp', 'Inex Complete', 40.00),
('images/yyy.webp', 'Soe Sweatshirt', 40.00),
('images/download (1)4.jpg', 'Gew Complete', 45.00),
('images/stray.jpg', 'White Tshirt', 20.00),
('images/re.jpg', 'Yellow Tshirt', 30.00),
('images/shopping.webp', 'Sev Complete', 55.00),
('images/shopping%20(1).webp', 'Brown Jacket', 75.00),
('images/bf8bd03b1c9afbe5b3285b57606d1db9_1743e0ef477f.webp', 'Graphic Hoodie', 50.00);